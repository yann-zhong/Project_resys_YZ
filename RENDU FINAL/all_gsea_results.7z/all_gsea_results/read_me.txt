gsea_it_1: results with no filter
gsea_it_2: results with top 1000 logFC (absolute values)